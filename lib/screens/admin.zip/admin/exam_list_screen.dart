import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ExamListScreen extends StatefulWidget {
  const ExamListScreen({super.key});

  @override
  State<ExamListScreen> createState() => _ExamListScreenState();
}

class _ExamListScreenState extends State<ExamListScreen> {
  final String baseUrl = "http://192.168.29.79:5000/api";

  List<dynamic> exams = [];
  bool loading = false;

  @override
  void initState() {
    super.initState();
    fetchExams();
  }

  Future<void> fetchExams() async {
    try {
      setState(() {
        loading = true;
      });

      final response = await http.get(
        Uri.parse("$baseUrl/admin/exams"),
        headers: {
          "Content-Type": "application/json",
          // "Authorization": "Bearer your_token",
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        setState(() {
          exams = data["exams"] ?? [];
        });
      } else {
        showMessage("Error", "Failed to load exams from server");
      }
    } catch (e) {
      debugPrint("Failed to fetch exams: $e");
      showMessage("Error", "Failed to load exams from server");
    } finally {
      setState(() {
        loading = false;
      });
    }
  }

  Future<void> handleDelete(dynamic id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Delete Exam"),
        content: const Text("Are you sure you want to delete this exam?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("Cancel"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Delete"),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      final response = await http.delete(
        Uri.parse("$baseUrl/admin/exams/$id"),
        headers: {
          "Content-Type": "application/json",
          // "Authorization": "Bearer your_token",
        },
      );

      if (response.statusCode == 200) {
        setState(() {
          exams.removeWhere((e) => e["id"] == id);
        });
        showMessage("Success", "Exam deleted successfully");
      } else {
        String message = "Unable to delete exam";
        try {
          final data = jsonDecode(response.body);
          message = data["message"]?.toString() ?? message;
        } catch (_) {}
        showMessage("Error", message);
      }
    } catch (e) {
      debugPrint("Failed to delete exam: $e");
      showMessage("Error", "Unable to delete exam");
    }
  }

  void showMessage(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  String formatDate(dynamic value) {
    if (value == null) return "-";

    try {
      final date = DateTime.parse(value.toString()).toLocal();
      final day = date.day.toString().padLeft(2, '0');
      final month = date.month.toString().padLeft(2, '0');
      final year = date.year.toString();
      final hour12 = (date.hour % 12 == 0 ? 12 : date.hour % 12)
          .toString()
          .padLeft(2, '0');
      final minute = date.minute.toString().padLeft(2, '0');
      final amPm = date.hour >= 12 ? "PM" : "AM";

      return "$day/$month/$year $hour12:$minute $amPm";
    } catch (e) {
      return value.toString();
    }
  }

  Widget buildRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w700,
                color: Color(0xff374151),
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: Color(0xff111827),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildExamCard(Map<String, dynamic> item, int index) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: const [
          BoxShadow(
            color: Color.fromRGBO(0, 0, 0, 0.08),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            item["title"]?.toString() ?? "Untitled Exam",
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: Color(0xff1f2937),
            ),
          ),
          const SizedBox(height: 12),

          buildRow("Sr. No:", "${index + 1}"),
          buildRow("Subject:", item["subject"]?.toString() ?? "-"),
          buildRow("Level:", item["level_number"]?.toString() ?? "-"),
          buildRow("Questions:", item["total_questions"]?.toString() ?? "0"),
          buildRow("Start Time:", formatDate(item["start_time"])),
          buildRow("End Time:", formatDate(item["end_time"])),
          buildRow(
            "Duration:",
            "${item["duration_minutes"]?.toString() ?? "0"} mins",
          ),

          const SizedBox(height: 14),

          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(
                      context,
                      "/exam-edit",
                      arguments: {"id": item["id"]},
                    ).then((_) => fetchExams());
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xff16a34a),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    elevation: 0,
                  ),
                  child: const Text(
                    "Edit",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  onPressed: () => handleDelete(item["id"]),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xffdc2626),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    elevation: 0,
                  ),
                  child: const Text(
                    "Delete",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff3f4f6),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Manage Exams",
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: Color(0xff111827),
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      "Create, edit and control exam schedules",
                      style: TextStyle(
                        fontSize: 14,
                        color: Color(0xff6b7280),
                      ),
                    ),
                    const SizedBox(height: 14),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pushNamed(context, "/exam-add")
                            .then((_) => fetchExams());
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xff2563eb),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        padding: const EdgeInsets.symmetric(
                          vertical: 12,
                          horizontal: 16,
                        ),
                        elevation: 0,
                      ),
                      child: const Text(
                        "+ Add Exam",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              Expanded(
                child: loading
                    ? const Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircularProgressIndicator(
                              color: Color(0xff4f46e5),
                            ),
                            SizedBox(height: 10),
                            Text(
                              "Loading Exams...",
                              style: TextStyle(
                                color: Color(0xff6b7280),
                                fontSize: 15,
                              ),
                            ),
                          ],
                        ),
                      )
                    : exams.isEmpty
                        ? const Center(
                            child: Text(
                              "No exams found",
                              style: TextStyle(
                                fontSize: 16,
                                color: Color(0xff6b7280),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          )
                        : ListView.builder(
                            itemCount: exams.length,
                            itemBuilder: (context, index) {
                              final item =
                                  Map<String, dynamic>.from(exams[index]);
                              return buildExamCard(item, index);
                            },
                          ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}