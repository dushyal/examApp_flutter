// import 'package:dio/dio.dart';
// import '../storage/local_storage.dart';

// class ApiClient {
//   static const String baseUrl = 'http://192.168.29.79:5000/api';

//   static final Dio dio = Dio(
//     BaseOptions(
//       baseUrl: baseUrl,
//       connectTimeout: const Duration(seconds: 15),
//       receiveTimeout: const Duration(seconds: 15),
//       sendTimeout: const Duration(seconds: 15),
//       headers: {
//         'Content-Type': 'application/json',
//       },
//     ),
//   )..interceptors.add(
//       InterceptorsWrapper(
//         onRequest: (options, handler) async {
//           final token = await LocalStorage.getToken();
//           print('TOKEN => $token');

//           if (token != null && token.isNotEmpty) {
//             options.headers['Authorization'] = 'Bearer $token';
//           }

//           handler.next(options);
//         },
//         onResponse: (response, handler) {
//           handler.next(response);
//         },
//         onError: (DioException err, handler) {
//           print('API ERROR STATUS => ${err.response?.statusCode}');
//           print('API ERROR DATA => ${err.response?.data}');
//           handler.next(err);
//         },
//       ),
//     );
// }






// import 'package:dio/dio.dart';
// import '../storage/local_storage.dart';

// class ApiClient {
//   static const String baseUrl = 'http://192.168.29.79:5000/api';

//   static final Dio dio = Dio(
//     BaseOptions(
//       baseUrl: baseUrl,
//       connectTimeout: const Duration(seconds: 15),
//       receiveTimeout: const Duration(seconds: 15),
//       sendTimeout: const Duration(seconds: 15),
//       headers: {
//         'Content-Type': 'application/json',
//       },
//     ),
//   )..interceptors.add(
//       InterceptorsWrapper(
//         onRequest: (options, handler) async {
//           final token = await LocalStorage.getToken();
//           print('TOKEN => $token');
//           print('REQUEST URL => ${options.baseUrl}${options.path}');
//           print('REQUEST METHOD => ${options.method}');
//           print('REQUEST DATA => ${options.data}');
//           print('REQUEST HEADERS => ${options.headers}');

//           if (token != null && token.isNotEmpty) {
//             options.headers['Authorization'] = 'Bearer $token';
//           }

//           handler.next(options);
//         },
//         onResponse: (response, handler) {
//           print('RESPONSE STATUS => ${response.statusCode}');
//           print('RESPONSE DATA => ${response.data}');
//           handler.next(response);
//         },
//         onError: (DioException err, handler) {
//           print('API ERROR TYPE => ${err.type}');
//           print('API ERROR MESSAGE => ${err.message}');
//           print('API ERROR STATUS => ${err.response?.statusCode}');
//           print('API ERROR DATA => ${err.response?.data}');
//           print('API ERROR => $err');
//           handler.next(err);
//         },
//       ),
//     );
// }




import 'package:dio/dio.dart';
import '../storage/local_storage.dart';

class ApiClient {
  static const String baseUrl = 'http://192.168.29.79:5000/api';

  static final Dio dio = Dio(
    BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
      sendTimeout: const Duration(seconds: 15),
      headers: {
        'Content-Type': 'application/json',
      },
    ),
  )
    ..interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await LocalStorage.getToken();

          if (token != null && token.isNotEmpty) {
            options.headers['Authorization'] = 'Bearer $token';
          }

          print('REQUEST URL => ${options.baseUrl}${options.path}');
          print('REQUEST METHOD => ${options.method}');
          print('REQUEST DATA => ${options.data}');
          print('REQUEST HEADERS => ${options.headers}');

          handler.next(options);
        },
        onResponse: (response, handler) {
          print('RESPONSE STATUS => ${response.statusCode}');
          print('RESPONSE DATA => ${response.data}');
          handler.next(response);
        },
        onError: (DioException err, handler) {
          print('API ERROR TYPE => ${err.type}');
          print('API ERROR MESSAGE => ${err.message}');
          print('API ERROR STATUS => ${err.response?.statusCode}');
          print('API ERROR DATA => ${err.response?.data}');
          handler.next(err);
        },
      ),
    );
}